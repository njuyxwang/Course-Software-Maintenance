/* crypt.c (dummy version) -- do not perform encryption
 * Hardly worth copyrighting :-)
 */
#ifdef RCSID
static char rcsid[] = "$Id: crypt.c,v 1.1.1.1 1996/05/22 22:57:42 dje Exp $";
#endif
